package conf

var Conf *Config
