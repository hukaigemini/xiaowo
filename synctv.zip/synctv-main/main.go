package main

import "github.com/synctv-org/synctv/cmd"

func main() {
	cmd.Execute()
}
