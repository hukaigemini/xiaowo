from py2app.util import codesign_adhoc

APPDIR = 'dist/Syncplay.app'

codesign_adhoc(APPDIR)
